import React from "react";
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Alert,
  StyleSheet,
  StatusBar,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import DogIcon from "../../assets/images/dog_icon.svg";

export default function PetScreen() {
  const navigation = useNavigation();

  const handleComprehensiveInspection = () => {
    Alert.alert("종합 검사", "종합 검사 화면으로 이동합니다.");
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      <ScrollView
        contentContainerStyle={styles.scrollContainer}
        showsVerticalScrollIndicator={false}
      >
        {/* ===== Hero ===== */}
        <View style={[styles.heroCard, styles.heroShadow]}>
          {/* 얇은 그라데이션 보더 */}
          <LinearGradient
            colors={["#DFF4C8", "#F5FFE9"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.heroBorder}
          >
            {/* 안쪽 본문 */}
            <View style={styles.heroInner}>
              <Text style={styles.heroEyebrow}>WELLNESS</Text>
              <Text style={styles.heroTitle} numberOfLines={2}>
                반려견 건강 케어
              </Text>
              <Text style={styles.heroDesc} numberOfLines={2}>
                자가검사와 실시간 체크를 한 곳에서.
              </Text>

              <TouchableOpacity
                activeOpacity={0.9}
                onPress={handleComprehensiveInspection}
                style={styles.heroBtn}
              >
                <Text style={styles.heroBtnText}>종합 검사 시작</Text>
              </TouchableOpacity>
            </View>
          </LinearGradient>
        </View>

        {/* ===== Self-check Section ===== */}
        <SectionHeader title="자가검사 가이드" subtitle="간단한 절차로 주요 증상을 점검하세요." />

        <View style={styles.rowWrap}>
          <HalfTile
            title="① 안구질환 검사"
            subtitle="눈물/충혈/이물감"
            onPress={() => navigation.navigate("EyeGuide")}
          />
          <HalfTile
            title="② 피부질환 검사"
            subtitle="발진/탈모/가려움"
            onPress={() => navigation.navigate("SkinGuide")}
          />
        </View>

        {/* ===== Live monitors ===== */}
        <SectionHeader title="실시간 측정" subtitle="심장 박동, 체온, 소리 패턴을 확인하세요." />

        <FullTile
          title="심장박동 체크"
          subtitle="안정·활동 시 비교"
          tint="#FFE5E5"
          onPress={() => Alert.alert("심장박동", "심장박동 체크 화면으로 이동합니다.")}
        />
        <FullTile
          title="체온 체크"
          subtitle="정상 37–39°C"
          tint="#D9E8FF"
          onPress={() => Alert.alert("체온", "체온 체크 화면으로 이동합니다.")}
        />
        <FullTile
          title="소리 인식"
          subtitle="짖음/낑낑거림 감지"
          tint="#E6FFE6"
          onPress={() => Alert.alert("소리 인식", "소리 인식 화면으로 이동합니다.")}
        />

        {/* ===== Tip ===== */}
        <View style={[styles.tipCard, shadow(1)]}>
          <Text style={styles.tipTitle}>작은 변화도 기록하세요</Text>
          <Text style={styles.tipDesc}>
            식욕·활동량·수면 패턴의 변화는 건강 신호일 수 있어요. 이상을 느끼면
            자가검사 후 수의사 상담을 권장합니다.
          </Text>
        </View>

        <View style={{ height: 16 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

/* ================== Sub Components ================== */

function SectionHeader({ title, subtitle }) {
  return (
    <View style={styles.sectionHeader}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {!!subtitle && <Text style={styles.sectionSubtitle}>{subtitle}</Text>}
    </View>
  );
}

function IconCapsule({ tint = "#F0F2F0" }) {
  return (
    <View style={[styles.iconCapsule, { backgroundColor: tint }]}>
      <DogIcon width={20} height={20} />
    </View>
  );
}

function HalfTile({ title, subtitle, onPress }) {
  return (
    <TouchableOpacity activeOpacity={0.9} onPress={onPress} style={[styles.halfTile, shadow(2)]}>
      <View style={styles.tileInner}>
        <IconCapsule tint="#EAF3FF" />
        <View style={{ flex: 1 }}>
          <Text numberOfLines={1} style={styles.tileTitle}>
            {title}
          </Text>
          <Text numberOfLines={1} style={styles.tileSubtitle}>
            {subtitle}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

function FullTile({ title, subtitle, onPress, tint = "#F2F2F2" }) {
  return (
    <TouchableOpacity activeOpacity={0.9} onPress={onPress} style={[styles.fullTile, shadow(2)]}>
      <View style={[styles.fullTileTint, { backgroundColor: tint }]}>
        <DogIcon width={20} height={20} />
      </View>
      <View style={{ flex: 1 }}>
        <Text numberOfLines={1} style={styles.tileTitle}>
          {title}
        </Text>
        <Text numberOfLines={1} style={styles.tileSubtitle}>
          {subtitle}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

/* ================== Styles ================== */

function shadow(level = 3) {
  const opacity = [0, 0.06, 0.08, 0.1, 0.12][Math.min(level, 4)];
  const radius = [0, 6, 10, 14, 18][Math.min(level, 4)];
  const height = [0, 6, 8, 10, 12][Math.min(level, 4)];
  return {
    shadowColor: "#000",
    shadowOpacity: opacity,
    shadowRadius: radius,
    shadowOffset: { width: 0, height: height },
    elevation: Math.max(2, level + 1),
  };
}

const CARD_R = 14;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F7FAF7",
  },
  scrollContainer: {
    paddingBottom: 12,
  },

  /* Hero - 새 디자인 */
  heroCard: {
    marginTop: 8,
    marginHorizontal: 16,
    borderRadius: 20,
    overflow: "hidden",          // 둥근 모서리 밖 요소 깔끔하게
    backgroundColor: "#FFFFFF",
  },
  heroShadow: {
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 6 },
    elevation: 2,
  },
  heroBorder: {
    borderRadius: 20,
    padding: 1.2,                // 테두리처럼 보이는 얇은 그라데이션
  },
  heroInner: {
    borderRadius: 18,
    backgroundColor: "#F7FFF1",  // 라이트 톤 배경
    paddingVertical: 20,
    paddingHorizontal: 18,
  },
  heroEyebrow: {
    fontSize: 11,
    fontWeight: "700",
    color: "#6FA66D",
    letterSpacing: 1.2,
  },
  heroTitle: {
    marginTop: 6,
    fontSize: 21,
    fontWeight: "800",
    color: "#1F3326",
  },
  heroDesc: {
    marginTop: 6,
    fontSize: 13,
    color: "#54705E",
  },
  heroBtn: {
    marginTop: 14,
    alignSelf: "flex-start",
    backgroundColor: "#184A2C",
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 16,
    minHeight: 36,
  },
  heroBtnText: {
    color: "#FFFFFF",
    fontWeight: "700",
    fontSize: 14,
  },

  /* Section */
  sectionHeader: {
    paddingHorizontal: 16,
    paddingTop: 18,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "800",
    color: "#263238",
  },
  sectionSubtitle: {
    marginTop: 4,
    fontSize: 12,
    color: "#6B7A89",
  },

  /* 2-column row */
  rowWrap: {
    paddingHorizontal: 16,
    paddingTop: 12,
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },

  /* Tiles: consistent height & spacing */
  halfTile: {
    flexBasis: "48%",
    backgroundColor: "#FFFFFF",
    borderRadius: CARD_R,
    paddingVertical: 14,
    paddingHorizontal: 12,
  },
  tileInner: {
    flexDirection: "row",
    gap: 10,
    alignItems: "center",
  },
  iconCapsule: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  tileTitle: {
    fontSize: 14,
    fontWeight: "800",
    color: "#1E3A2A",
  },
  tileSubtitle: {
    marginTop: 2,
    fontSize: 11,
    color: "#567A68",
  },

  fullTile: {
    marginHorizontal: 16,
    marginTop: 12,
    backgroundColor: "#FFFFFF",
    borderRadius: CARD_R,
    paddingVertical: 14,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  
  fullTileTint: {
    width: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },

  /* Tip */
  tipCard: {
    marginTop: 16,
    marginHorizontal: 16,
    backgroundColor: "#FFFFFF",
    borderRadius: CARD_R,
    padding: 14,
  },
  tipTitle: {
    fontSize: 14,
    fontWeight: "800",
    color: "#184A2C",
  },
  tipDesc: {
    marginTop: 6,
    fontSize: 12,
    color: "#567A68",
    lineHeight: 18,
  },
});

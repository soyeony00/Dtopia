import React, { useState, useEffect } from "react";
import { useNavigation, useRoute } from "@react-navigation/native";
import { SafeAreaView, Pressable, StyleSheet, Text, View, Alert } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import BackIcon from "../../assets/images/back.svg";
import { height, width } from "../../globalDimension";

export const hourArray = Array.from({ length: 12 }, (_, index) => ({
  id: index + 1,
}));

export const minuteArray = Array.from({ length: 12 }, (_, index) => {
  const value = index * 5;
  return { id: value < 10 ? `0${value}` : `${value}` };
});

export const everyDateArray = ["매주", "매월"];
export const dateArray = ["월", "화", "수", "목", "금", "토", "일"];

const dayToNumber = {
  "월": 1,
  "화": 2,
  "수": 3,
  "목": 4,
  "금": 5,
  "토": 6,
  "일": 7,
};

function getNextAlarmDateTime(selectedDay, selectedHour, selectedMinute, ampm) {
  const now = new Date();
  const targetDate = new Date(now);

  const weekDays = ["월", "화", "수", "목", "금", "토", "일"];
  const selectedWeekDay = weekDays.indexOf(selectedDay);
  const today = now.getDay();
  const adjustedToday = today === 0 ? 6 : today - 1;

  const hour24 = ampm === "pm" ? (selectedHour % 12) + 12 : selectedHour;

  let dayOffset = selectedWeekDay - adjustedToday;
  if (
    dayOffset < 0 ||
    (dayOffset === 0 &&
      (hour24 < now.getHours() ||
        (hour24 === now.getHours() && parseInt(selectedMinute) <= now.getMinutes())))
  ) {
    dayOffset += 7;
  }

  targetDate.setDate(now.getDate() + dayOffset);
  targetDate.setHours(hour24);
  targetDate.setMinutes(parseInt(selectedMinute));
  targetDate.setSeconds(0);

  return `${targetDate.getFullYear()}년 ${targetDate.getMonth() + 1}월 ${targetDate.getDate()}일 ${ampm === "pm" ? "오후" : "오전"} ${selectedHour}시 ${selectedMinute}분`;
}

export default function AlarmDetail() {
  const navigation = useNavigation();
  const route = useRoute();

  const [activeAmPm, setActiveAmPm] = useState(route.params?.activeAmPm || "am");
  const [hour, setHour] = useState(parseInt(route.params?.hour) || 1);
  const [minute, setMinute] = useState(route.params?.minute || "00");
  const [eDate, setEdate] = useState(route.params?.eDate || "매주");
  const [date, setDate] = useState(route.params?.date || "월");
  const [nextDateTimeText, setNextDateTimeText] = useState("");

  useEffect(() => {
    const result = getNextAlarmDateTime(date, hour, minute, activeAmPm);
    setNextDateTimeText(result);
  }, [date, hour, minute, activeAmPm]);

  const saveData = async () => {
    try {
      const value = { activeAmPm, hour, minute, eDate, date };
      await AsyncStorage.setItem("dateData", JSON.stringify(value));

      const hour24 = activeAmPm === "pm" ? (hour % 12) + 12 : hour;
      const hourStr = hour24 < 10 ? `0${hour24}` : `${hour24}`;
      const timeStr = `${hourStr}:${minute}`;

      let notification_type = "weekly";
      if (eDate === "매월") notification_type = "monthly";

      const payload = {
        notification_type,
        notification_days: [dayToNumber[date]],
        notification_time: timeStr,
      };

      const token = await AsyncStorage.getItem("authToken");

      if (!token) {
        Alert.alert("인증 실패", "로그인이 필요합니다.");
        return;
      }

      const res = await axios.post(
        "http://dtopia.jumpingcrab.com:5151/api/user/notifytime",
        payload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      console.log("✅ 서버 응답:", res.data);
      navigation.navigate("Profile");
    } catch (error) {
      console.error("❌ 알림 저장 또는 서버 전송 실패:", error);
      Alert.alert("알림 저장 실패", "서버 전송 중 오류가 발생했습니다.");
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "white" }}>
      <View style={styles.header}>
        <Pressable style={styles.backButton} onPress={() => navigation.goBack()}>
          <BackIcon />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>알림 설정</Text>
        </View>
      </View>

      <View style={{ flex: 1, justifyContent: "space-between" }}>
        <View>
          <View style={styles.MorningAfternoon}>
            {["am", "pm"].map((period) => (
              <Pressable key={period} onPress={() => setActiveAmPm(period)}>
                <View
                  style={[
                    period === "am" ? styles.Morning : styles.Afternoon,
                    activeAmPm === period && { backgroundColor: "#A8DF8E" },
                  ]}
                >
                  <Text style={styles.text}>{period === "am" ? "오전" : "오후"}</Text>
                </View>
              </Pressable>
            ))}
          </View>

          <View style={styles.Hour}>
            <Text style={styles.text}>시</Text>
            <View style={styles.HourText}>
              {hourArray.map((item) => (
                <Pressable key={item.id} onPress={() => setHour(item.id)}>
                  <View style={[styles.HourItem, hour === item.id && { backgroundColor: "#FFE5E5" }]}>
                    <Text style={styles.HourItmeText}>{item.id}</Text>
                  </View>
                </Pressable>
              ))}
            </View>
          </View>

          <View style={styles.Minute}>
            <Text style={styles.text}>분</Text>
            <View style={styles.MinuteText}>
              {minuteArray.map((item) => (
                <Pressable key={item.id} onPress={() => setMinute(item.id)}>
                  <View style={[styles.MinuteItem, minute === item.id && { backgroundColor: "#FFE5E5" }]}>
                    <Text style={styles.MinuteItmeText}>{item.id}</Text>
                  </View>
                </Pressable>
              ))}
            </View>
          </View>

          <View style={styles.everyDateContainer}>
            {everyDateArray.map((item) => (
              <Pressable key={item} onPress={() => setEdate(item)}>
                <View style={[styles.eDate, eDate === item && { backgroundColor: "#A8DF8E" }]}>
                  <Text style={styles.everyDateText}>{item}</Text>
                </View>
              </Pressable>
            ))}
          </View>

          <View style={styles.dateContainer}>
            {dateArray.map((item) => (
              <Pressable key={item} onPress={() => setDate(item)}>
                <View style={[styles.date, date === item && { backgroundColor: "#FFE5E5" }]}>
                  <Text style={styles.dateText}>{item}</Text>
                </View>
              </Pressable>
            ))}
          </View>

          <View style={{ alignItems: "center", marginTop: height * 20 }}>
            <Text style={{ fontSize: width * 14, color: "gray" }}>
              🔔 {nextDateTimeText}에 알림이 울릴 예정입니다
            </Text>
          </View>
        </View>

        <View style={{ alignItems: "center" }}>
          <Pressable onPress={saveData}>
            <View style={styles.saveButton}>
              <Text>저장하기</Text>
            </View>
          </Pressable>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    paddingHorizontal: width * 20,
    alignItems: "center",
    marginTop: height * 15,
    marginBottom: height * 15,
  },
  backButton: {
    position: "absolute",
    left: width * 20,
    zIndex: 2,
  },
  headerTitle: {
    textAlign: "center",
    fontSize: width * 16,
    fontWeight: "500",
  },
  MorningAfternoon: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: height * 20,
    paddingHorizontal: width * 28,
  },
  Morning: {
    backgroundColor: "#EFEFEF",
    width: width * 167,
    height: height * 55,
    alignItems: "center",
    justifyContent: "center",
    borderTopLeftRadius: width * 15,
    borderBottomLeftRadius: width * 15,
  },
  Afternoon: {
    backgroundColor: "#EFEFEF",
    width: width * 167,
    height: height * 55,
    alignItems: "center",
    justifyContent: "center",
    borderTopRightRadius: width * 15,
    borderBottomRightRadius: width * 15,
  },
  text: {
    fontSize: width * 20,
    fontWeight: "700",
    color: "#000",
  },
  Hour: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: width * 35,
    paddingTop: height * 50,
  },
  HourText: {
    marginLeft: width * 18,
    flexDirection: "row",
    flexWrap: "wrap",
    gap: width * 16,
  },
  HourItem: {
    width: width * 30,
    height: width * 30,
    backgroundColor: "#F5F5F5",
    alignItems: "center",
    justifyContent: "center",
  },
  HourItmeText: {
    fontSize: width * 16,
    fontWeight: "500",
    color: "#000",
  },
  Minute: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: width * 35,
    paddingTop: height * 30,
  },
  MinuteText: {
    marginLeft: width * 18,
    flexDirection: "row",
    flexWrap: "wrap",
    gap: width * 16,
  },
  MinuteItem: {
    width: width * 30,
    height: width * 30,
    backgroundColor: "#F5F5F5",
    alignItems: "center",
    justifyContent: "center",
  },
  MinuteItmeText: {
    fontSize: width * 16,
    fontWeight: "500",
    color: "#000",
  },
  everyDateContainer: {
    flexDirection: "row",
    marginTop: height * 50,
    justifyContent: "space-around",
    paddingHorizontal: width * 40,
  },
  eDate: {
    width: width * 76,
    height: height * 38,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F5F5F5",
    borderRadius: width * 15,
  },
  everyDateText: {
    fontSize: width * 15,
    fontWeight: "600",
    textAlign: "center",
  },
  dateContainer: {
    flexDirection: "row",
    marginTop: height * 50,
    justifyContent: "space-around",
    paddingHorizontal: width * 45,
  },
  date: {
    width: width * 30,
    height: width * 30,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F5F5F5",
  },
  dateText: {
    fontSize: width * 20,
    fontWeight: "700",
    textAlign: "center",
  },
  saveButton: {
    width: width * 96,
    height: height * 36,
    backgroundColor: "#F3FDE8",
    borderColor: "#A8DF8E",
    borderWidth: width * 2,
    borderRadius: width * 15,
    justifyContent: "center",
    alignItems: "center",
    marginVertical: height * 20,
  },
});

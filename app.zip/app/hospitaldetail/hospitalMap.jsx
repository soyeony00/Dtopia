import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  View,
  Text,
  Pressable,
  Image,
  SafeAreaView,
  FlatList,
  Alert,
  Platform,
  PermissionsAndroid,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import Geolocation from "@react-native-community/geolocation";
import { Row } from "../../components/ui/Row";
import { FilterButton } from "../../components/shared/FilterButton";
import { HospitalItem } from "../../components/shared/HospitalItem";
import BackIcon from "../../assets/images/back.svg";

const filters = [
  { id: 1, title: "가까운 거리순" },
  { id: 2, title: "진료 중" },
  { id: 3, title: "평점 높은 순" },
];

const KAKAO_REST_API_KEY = "8c33432bf2577f08b42a4c51693ab56a";

export default function HospitalDetail() {
  const navigation = useNavigation();
  const [selectedFilter, setSelectedFilter] = useState(null);
  const [hospitals, setHospitals] = useState([]);

  useEffect(() => {
    const fetchHospitals = async () => {
      try {
        if (Platform.OS === "android") {
          const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
          );
          if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
            Alert.alert("권한 필요", "위치 권한을 허용해주세요.");
            return;
          }
        }

        Geolocation.getCurrentPosition(
          async (pos) => {
            const { latitude, longitude } = pos.coords;
            console.log("📍 현재 위치:", latitude, longitude);

            const query = `https://dapi.kakao.com/v2/local/search/keyword.json?query=동물병원&x=${longitude}&y=${latitude}&radius=3000`;

            console.log("🔍 API 요청 URL:", query);

            const res = await fetch(query, {
              headers: {
                Authorization: `KakaoAK ${KAKAO_REST_API_KEY}`,
              },
            });

            console.log("✅ 응답 상태 코드:", res.status);
            const json = await res.json();
            console.log("📦 응답 데이터:", JSON.stringify(json, null, 2));

            if (json.documents && json.documents.length > 0) {
              const enriched = json.documents.map((place, idx) => ({
                id: idx + 1,
                name: place.place_name,
                phone: place.phone || null,
                road_address: place.road_address_name || null,
                address: place.address_name || null,
                location_link: `https://map.kakao.com/link/map/${encodeURIComponent(place.place_name)},${place.y},${place.x}`,
                lat: place.y, // ✅ 위도 추가
                lng: place.x, // ✅ 경도 추가
              }));
              setHospitals(enriched);
            } else {
              Alert.alert("검색 실패", "병원 데이터를 찾을 수 없습니다.");
            }
          },
          (err) => {
            console.error("❌ 위치 가져오기 실패:", err);
            Alert.alert("위치 에러", "현재 위치를 가져오지 못했습니다.");
          },
          { enableHighAccuracy: true }
        );
      } catch (e) {
        console.error("🚨 예외 발생:", e);
        Alert.alert("오류", "병원 데이터를 불러오는 중 문제가 발생했습니다.");
      }
    };

    fetchHospitals();
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <Row gap={8}>
            <Text style={styles.headerTitle}>주변 동물병원</Text>
            <Pressable onPress={() => navigation.navigate("hospitalSearch")}>
              <Image
                style={{ width: 16, height: 16 }}
                source={require("../../assets/images/search.png")}
              />
            </Pressable>
          </Row>
          <Pressable
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <BackIcon />
          </Pressable>
        </View>

        <View style={styles.filterButtonContainer}>
          {filters.map((item) => (
            <FilterButton
              key={item.id}
              title={item.title}
              onClick={() => setSelectedFilter(item)}
              isSelected={item === selectedFilter}
            />
          ))}
        </View>
      </View>

      <FlatList
        data={hospitals}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => <HospitalItem hospital={item} />}
        contentContainerStyle={{ paddingVertical: 10 }}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  header: {
    paddingHorizontal: 16,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderColor: "#eee",
    paddingBottom: 10,
  },
  headerContent: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 10,
    position: "relative",
  },
  backButton: {
    position: "absolute",
    left: 0,
    top: 0,
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
  filterButtonContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: 5,
  },
});

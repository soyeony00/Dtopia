import React from "react";
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Image,
  TouchableOpacity,
  ScrollView,
  Dimensions,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

const { width } = Dimensions.get("window");
const IMAGE_SIZE = width * 0.42; // 정사각형 이미지 크기

export default function EyeGuideScreen() {
  const navigation = useNavigation();

  const handleStartDetection = () => {
    navigation.navigate("EyeDetection");
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.title}>📸 반려동물 안구 질환 검사 가이드</Text>

        <Text style={styles.description}>
          이 검사는 반려견의 눈 사진을 기반으로 AI 모델이 질환 유무를 판별합니다.{"\n"}실시간 촬영 후
          서버로 이미지가 전송되어, 학습된 모델이 질병 여부를 분석합니다.
        </Text>

        <Text style={styles.sectionTitle}>🧪 진단 가능한 주요 질환</Text>
        <Text style={styles.bullet}>
          • 백내장 (cataract): 눈의 수정체가 혼탁해지는 질환
        </Text>
        <Text style={styles.bullet}>
          • 결막염 (conjunctivitis): 눈 흰자 부위 염증, 충혈, 눈곱
        </Text>
        <Text style={styles.bullet}>
          • 안검종양 (eyelid tumor): 눈 주변에 혹이 생기는 질환
        </Text>
        <Text style={styles.bullet}>
          • 궤양성 각막염 (ulcerative keratitis): 각막이 손상되어 염증이 생기는 질환
        </Text>
        <Text style={styles.bullet}>
          • 색소침착형 각막염 (pigmentary keratitis): 각막에 색소 침착이 발생하는 질환
        </Text>

        <Text style={styles.sectionTitle}>💡 검사 전 유의사항</Text>
        <Text style={styles.bullet}>
          • 촬영 시 눈에 빛이 반사되지 않도록 해주세요.
        </Text>
        <Text style={styles.bullet}>
          • 눈의 중심이 정확히 보이도록 가까이서 촬영하세요.
        </Text>
        <Text style={styles.bullet}>
          • 흔들리지 않도록 반려동물을 안정시킨 후 촬영하세요.
        </Text>

        <View style={styles.exampleRow}>
          <View style={styles.exampleBox}>
            <Image
              source={require("../../assets/images/eye_bad.jpg")}
              style={styles.exampleImage}
              resizeMode="cover"
            />
            <Text style={styles.exampleLabelWrong}>❌ 잘못된 예</Text>
            <Text style={styles.exampleExplain}>흐림, 반사, 눈 중심 미포함</Text>
          </View>

          <View style={styles.exampleBox}>
            <Image
              source={require("../../assets/images/eye_good.jpg")}
              style={styles.exampleImage}
              resizeMode="cover"
            />
            <Text style={styles.exampleLabelGood}>✅ 올바른 예</Text>
            <Text style={styles.exampleExplain}>또렷하고 정면으로 촬영</Text>
          </View>
        </View>

        <Text style={styles.notice}>
          ※ 본 검사는 참고용이며, 이상 소견이 있는 경우 반드시 동물병원에서 정확한 진단을 받으시길 권장합니다.
        </Text>

        <TouchableOpacity style={styles.startButton} onPress={handleStartDetection}>
          <Text style={styles.startButtonText}>검사 시작하기</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  scrollContent: {
    padding: 24,
    alignItems: "center",
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 16,
  },
  description: {
    fontSize: 14,
    color: "#555",
    textAlign: "center",
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#444",
    alignSelf: "flex-start",
    marginBottom: 8,
    marginTop: 16,
  },
  bullet: {
    fontSize: 13,
    color: "#444",
    alignSelf: "flex-start",
    marginBottom: 4,
  },
  exampleRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginTop: 30,
    marginBottom: 20,
  },
  exampleBox: {
    width: "48%",
    alignItems: "center",
  },
  exampleImage: {
    width: IMAGE_SIZE,
    height: IMAGE_SIZE,
    borderRadius: 10,
    marginBottom: 8,
  },
  exampleLabelWrong: {
    color: "#ff4d4d",
    fontWeight: "bold",
    fontSize: 15,
  },
  exampleLabelGood: {
    color: "#28a745",
    fontWeight: "bold",
    fontSize: 15,
  },
  exampleExplain: {
    fontSize: 12,
    color: "#666",
    textAlign: "center",
    marginTop: 2,
  },
  notice: {
    fontSize: 13,
    color: "#999",
    textAlign: "center",
    marginTop: 20,
    marginBottom: 30,
    paddingHorizontal: 10,
  },
  startButton: {
    backgroundColor: "#A8DF8E",
    paddingVertical: 16,
    paddingHorizontal: 40,
    borderRadius: 12,
  },
  startButtonText: {
    color: "#000",
    fontWeight: "bold",
    fontSize: 16,
  },
});
